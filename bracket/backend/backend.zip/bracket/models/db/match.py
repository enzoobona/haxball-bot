from datetime import datetime
from decimal import Decimal

from heliclockter import datetime_utc, timedelta
from pydantic import BaseModel, Field

from bracket.models.db.court import Court
from bracket.models.db.shared import BaseModelORM
from bracket.models.db.stage_item_inputs import StageItemInput
from bracket.utils.id_types import (
    CourtId,
    MatchId,
    PlayerId,
    RoundId,
    StageItemInputId,
    TeamId
)
from bracket.utils.types import assert_some


class MatchBaseInsertable(BaseModelORM):
    created: datetime_utc
    start_time: datetime_utc | None = None
    duration_minutes: int
    margin_minutes: int
    custom_duration_minutes: int | None = None
    custom_margin_minutes: int | None = None
    position_in_schedule: int | None = None
    round_id: RoundId
    stage_item_input1_score: int
    stage_item_input2_score: int
    court_id: CourtId | None = None
    stage_item_input1_conflict: bool
    stage_item_input2_conflict: bool

    @property
    def end_time(self) -> datetime_utc:
        assert self.start_time
        return self.start_time + timedelta(minutes=self.duration_minutes + self.margin_minutes)


class MatchInsertable(MatchBaseInsertable):
    stage_item_input1_id: StageItemInputId | None = None
    stage_item_input2_id: StageItemInputId | None = None
    stage_item_input1_winner_from_match_id: MatchId | None = None
    stage_item_input2_winner_from_match_id: MatchId | None = None


class Match(MatchInsertable):
    id: MatchId
    played: bool
    stage_item_input1: StageItemInput | None = None
    stage_item_input2: StageItemInput | None = None

    def get_winner(self) -> StageItemInput | None:
        if self.stage_item_input1_score > self.stage_item_input2_score:
            return self.stage_item_input1

        if self.stage_item_input1_score < self.stage_item_input2_score:
            return self.stage_item_input2

        return None


class MatchWithDetails(Match):
    """
    MatchWithDetails has zero or one defined stage item inputs, but not both.
    """

    court: Court | None = None
    # Número del partido DENTRO del torneo (1, 2, 3...), por orden de creación. Es el que se
    # usa en la sala de Haxball (`!partido N`). No es el id global de la base de datos.
    number: int | None = None


def get_match_hash(
    stage_item_input1_id: StageItemInputId | None,
    stage_item_input2_id: StageItemInputId | None,
) -> str:
    return f"{stage_item_input1_id}-{stage_item_input2_id}"


class MatchWithDetailsDefinitive(Match):
    stage_item_input1: StageItemInput
    stage_item_input2: StageItemInput
    court: Court | None = None
    number: int | None = None

    @property
    def stage_item_inputs(self) -> list[StageItemInput]:
        return [self.stage_item_input1, self.stage_item_input2]

    @property
    def stage_item_input_ids(self) -> list[StageItemInputId]:
        return [
            assert_some(self.stage_item_input1_id),
            assert_some(self.stage_item_input2_id),
        ]

    def get_input_ids_hashes(self) -> list[str]:
        return [
            get_match_hash(self.stage_item_input1_id, self.stage_item_input2_id),
            get_match_hash(self.stage_item_input2_id, self.stage_item_input1_id),
        ]


class MatchBody(BaseModelORM):
    round_id: RoundId
    stage_item_input1_score: int = 0
    stage_item_input2_score: int = 0
    court_id: CourtId | None = None
    custom_duration_minutes: int | None = None
    custom_margin_minutes: int | None = None


class MatchCreateBodyFrontend(BaseModelORM):
    round_id: RoundId
    court_id: CourtId | None = None
    stage_item_input1_id: StageItemInputId | None = None
    stage_item_input2_id: StageItemInputId | None = None
    stage_item_input1_winner_from_match_id: MatchId | None = None
    stage_item_input2_winner_from_match_id: MatchId | None = None


class MatchCreateBody(MatchCreateBodyFrontend):
    duration_minutes: int
    margin_minutes: int
    custom_duration_minutes: int | None = None
    custom_margin_minutes: int | None = None


class MatchRescheduleBody(BaseModelORM):
    old_court_id: CourtId
    old_position: int
    new_court_id: CourtId
    new_position: int


class MatchFilter(BaseModel):
    elo_diff_threshold: int
    only_recommended: bool
    limit: int
    iterations: int


class SuggestedMatch(BaseModel):
    stage_item_input1: StageItemInput
    stage_item_input2: StageItemInput
    elo_diff: Decimal
    swiss_diff: Decimal
    is_recommended: bool
    times_played_sum: int
    player_behind_schedule_count: int

    @property
    def stage_item_input_ids(self) -> list[int]:
        return [self.stage_item_input1.id, self.stage_item_input2.id]


class MatchHaxball(BaseModel):
    id: MatchId
    # Número del partido dentro del torneo (ver `MatchWithDetails.number`).
    number: int
    team_1_id: TeamId
    team_1_name: str
    team_2_id: TeamId
    team_2_name: str
    played: bool
    # Tipo de la fase del partido ("ROUND_ROBIN", "SINGLE_ELIMINATION" o "SWISS").
    # El bot lo usa para saber si un empate necesita desempate (eliminación).
    stage_type: str


class MatchPlayerStats(BaseModel):
    player_id: PlayerId
    team_id: TeamId
    goals: int = Field(default=0, ge=0)
    assists: int = Field(default=0, ge=0)
    own_goals: int = Field(default=0, ge=0)


class MatchPlayerStatsDetail(BaseModel):
    """Estadísticas de un jugador en un partido, con nombres listos para mostrar."""

    player_id: PlayerId
    player_name: str
    team_id: TeamId
    team_name: str
    goals: int = 0
    assists: int = 0
    own_goals: int = 0


class MatchFinishBody(BaseModel):
    stage_item_input1_score: int = Field(ge=0)
    stage_item_input2_score: int = Field(ge=0)
    player_stats: list[MatchPlayerStats]