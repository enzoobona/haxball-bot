import { Badge, Button, Card, Group, Image, Text, UnstyledButton } from '@mantine/core';
import i18n from 'i18next';
import { useTranslation } from 'react-i18next';
import { SWRResponse } from 'swr';

import { EmptyTableInfo } from '@components/no_content/empty_table_info';
import { DateTime } from '@components/utils/datetime';
import RequestErrorAlert from '@components/utils/error_alert';
import PreloadLink from '@components/utils/link';
import { TableSkeletonSingleColumn } from '@components/utils/skeletons';
import { Tournament, TournamentsResponse } from '@openapi';
import { getBaseApiUrl } from '@services/adapter';
import classes from './tournaments.module.css';

export function TournamentLogo({ tournament }: { tournament: Tournament }) {
  return (
    <Image
      radius="md"
      alt={i18n.t('logo_alt_tournament')}
      src={`${getBaseApiUrl()}/static/tournament-logos/${tournament.logo_path}`}
      fallbackSrc={`data:image/svg+xml;utf8,${encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="318" height="160"><rect width="100%" height="100%" fill="#4a1025"/></svg>',
      )}`}
      height={160}
    />
  );
}

function Stat({ title, value }: { title: string; value: any }) {
  return (
    <div key={title}>
      <Text size="xs" c="dimmed">
        {title}
      </Text>
      <Text fw={500} size="sm">
        {value}
      </Text>
    </div>
  );
}

export default function TournamentsCardTable({
  swrTournamentsResponse,
}: {
  swrTournamentsResponse: SWRResponse<TournamentsResponse>;
}) {
  const { t } = useTranslation();

  if (swrTournamentsResponse.error) {
    return <RequestErrorAlert error={swrTournamentsResponse.error} />;
  }
  if (swrTournamentsResponse.isLoading) {
    return <TableSkeletonSingleColumn />;
  }

  const tournaments: Tournament[] =
    swrTournamentsResponse.data != null ? swrTournamentsResponse.data.data : [];

  const rows = tournaments
    .sort((t1: Tournament, t2: Tournament) => t1.name.localeCompare(t2.name))
    .map((tournament) => (
      <Group key={tournament.id} className={classes.card}>
        <UnstyledButton
          component={PreloadLink}
          href={`/tournaments/${tournament.id}/stages`}
          w="100%"
        >
          <Card shadow="sm" padding="lg" radius="md" withBorder w="100%">
            <Card.Section>
              <TournamentLogo tournament={tournament} />
            </Card.Section>

            <Group justify="space-between" mt="md" mb="xs">
              <Text fw={500} lineClamp={1}>
                {tournament.name}
              </Text>
            </Group>

            <Card.Section className={classes.section}>
              <Stat title={t('start_time')} value={<DateTime datetime={tournament.start_time} />} />
            </Card.Section>

            <Card.Section className={classes.section}>
              <Group w="100%">
                <Badge
                  fullWidth
                  color="gray"
                  variant="outline"
                  size="lg"
                  style={{ visibility: tournament.status === 'ARCHIVED' ? 'visible' : 'hidden' }}
                >
                  {t('archived_label')}
                </Badge>
                <Button
                  component={PreloadLink}
                  color="brand"
                  fullWidth
                  radius="md"
                  href={`/tournaments/${tournament.id}/stages`}
                >
                  {t('open_button')}
                </Button>
              </Group>
            </Card.Section>
          </Card>
        </UnstyledButton>
      </Group>
    ));

  if (rows.length < 1) return <EmptyTableInfo entity_name={t('tournaments_title')} />;

  return (
    <Group gap="sm" style={{ width: '100%' }}>
      {rows}
    </Group>
  );
}
