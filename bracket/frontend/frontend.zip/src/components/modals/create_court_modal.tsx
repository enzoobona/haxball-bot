import { Button, Modal, TextInput } from '@mantine/core';
import { useForm } from '@mantine/form';
import { GoPlus } from '@react-icons/all-files/go/GoPlus';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SWRResponse } from 'swr';

import { CourtsResponse } from '@openapi';
import { createCourt } from '@services/court';

export default function CourtModal({
  tournamentId,
  swrCourtsResponse,
  buttonSize,
}: {
  buttonSize: 'xs' | 'lg';
  tournamentId: number;
  swrCourtsResponse: SWRResponse<CourtsResponse>;
}) {
  const { t } = useTranslation();
  const [opened, setOpened] = useState(false);
  const form = useForm({
    initialValues: {
      name: '',
    },

    validate: {
      name: (value) => (value.length > 0 ? null : t('too_short_name_validation')),
    },
  });

  return (
    <>
      <Modal opened={opened} onClose={() => setOpened(false)} title={t('add_court_title')}>
        <form
          onSubmit={form.onSubmit(async (values) => {
            await createCourt(tournamentId, values.name);
            await swrCourtsResponse.mutate();
            setOpened(false);
          })}
        >
          <TextInput
            withAsterisk
            label={t('name_input_label')}
            placeholder={t('court_name_input_placeholder')}
            {...form.getInputProps('name')}
          />

          <Button fullWidth style={{ marginTop: 10 }} type="submit">
            {t('save_button')}
          </Button>
        </form>
      </Modal>
      <Button
        variant="outline"
        color="green"
        size={buttonSize}
        style={{ marginRight: 10 }}
        onClick={() => setOpened(true)}
        leftSection={<GoPlus size={24} />}
      >
        {t('add_court_title')}
      </Button>
    </>
  );
}
